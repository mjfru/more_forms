// import { useState } from 'react'
import './App.css'
import Form from './components/form'

function App() {
  return (
    <div>
      <Form/>
    </div>
  )
}

export default App
