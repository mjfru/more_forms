
import { useState } from 'react';

const Form = (props) => {
    const [firstName, setFirstName] = useState("");
    const [firstNameError, setFirstNameError] = useState("");
    const [lastName, setLastName] = useState("");
    const [lastNameError, setLastNameError] = useState("");
    const [email, setEmail] = useState("");
    const [emailError, setEmailError] = useState("");
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("")
    const [confirmPasswordError, setConfirmPasswordError] = useState("");
    // const [hasBeenSubmitted, setHasBeenSubmitted] = useState("");

    const handleFirstName = (e) => {
        setFirstName(e.target.value);
        if(e.target.value.length < 2) {
            setFirstNameError("At least two characters are required for your first name");
        } else {
            setFirstNameError("");
        }
    }

    const handleLastName = (e) => {
        setLastName(e.target.value);
        if(e.target.value.length < 2) {
            setLastNameError("At least two characters are required for your last name.");
        } else {
            setLastNameError("");
        }
    }

    const handleEmail = (e) => {
        setEmail(e.target.value);
        if(e.target.value.length < 5) {
            setEmailError("At least five characters are required for your email.")
        } else {
            setEmailError("");
        }
    };

    const handlePassword = (e) => {
        setPassword(e.target.value);
        if(e.target.value.length < 8) {
            setPasswordError("At least eight characters are required for your password.")
        } else {
            setPasswordError("");
        }
    };

    const handleConfirmPassword = (e) => {
        setConfirmPassword(e.target.value);
        if(e.target.value !== password) {
            setConfirmPasswordError("Your passwords do not match. Please try again.")
        } else {
            setConfirmPasswordError("");
        }
    };

    const createUser = (e) => {
        e.preventDefault();

        const userInfo = { firstName, lastName, email, password, confirmPassword };
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");
        // setHasBeenSubmitted = ( true );
    };

    return (
    <>
        <h2>Create User</h2>
        <form onSubmit = { createUser }>
            <div>
                <label>First Name: </label>
                <input type="text" value={firstName} onChange={ handleFirstName } />
                {
                    firstNameError ?
                    <p>{ firstNameError }</p> :
                    ''
                }
            </div>
            <div>
                <label>Last Name: </label>
                <input type="text" value={lastName} onChange={ handleLastName } />
                {
                    lastNameError ?
                    <p>{ lastNameError }</p> :
                    ''
                }
            </div>
            <div>
                <label>Email: </label>
                <input type="text" value={email} onChange={ handleEmail } />
                {
                    emailError ?
                    <p> { emailError }</p> :
                    ''
                }
            </div>
            <div>
                <label>Password: </label>
                <input type="password" value={password} onChange={ handlePassword } />
                {
                    passwordError ?
                    <p> {passwordError} </p> :
                    ''
                }
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type="password" value={confirmPassword} onChange={ handleConfirmPassword } />
                {
                    confirmPasswordError ?
                    <p> {confirmPasswordError} </p> :
                    ''
                }
            </div>
            <input type="submit" value="Create User" />
            <hr />
        </form>
        <div>
            <h4>Confirm User Input:</h4>
            <div>
                <label>First Name: {firstName}</label>
            </div>
            <div>
                <label>Last Name: {lastName}</label>
            </div>
            <div>
                <label>Email: {email}</label>
            </div>
            <div>
                <label>Password: {password}</label>
            </div>
            <div>
                <label>Confirm Password: {confirmPassword}</label>
            </div>
        </div>
    </>
    );
};

export default Form